drop table DEVICES;
drop table CONFIGWORDS;
drop table CONFIGSETTINGS;
drop table CONFIGFIELDS;

create table DEVICES (
     DEVICEROWID integer primary key autoincrement,
     DEVICEID integer not null,
     FAMILYID integer not null,
     PARTNAME text not null, 
     BYTESPERWORDFLASH integer,
     WRITEFLASHBLOCKSIZE integer not null,
     ERASEFLASHBLOCKSIZE integer not null,
     STARTFLASH integer,
     ENDFLASH integer,
     STARTEE integer, 
     ENDEE integer, 
     STARTUSER integer,
     ENDUSER integer, 
     STARTCONFIG integer,
     ENDCONFIG integer,
     STARTDEVICEID integer,
     ENDDEVICEID integer,
     DEVICEIDMASK integer,
     STARTGPR integer,
     ENDGPR integer
);

create table CONFIGWORDS (
     ROWID integer primary key autoincrement,
     DEVICEROWID integer not null,
     CONFIGNAME text not null,
     ADDRESS integer not null,
     DEFAULTVALUE integer,
     IMPLEMENTEDBITS integer
);

create table CONFIGFIELDS (
     ROWID integer primary key autoincrement,
     CONFIGWORDID integer not null,
     DEVICEROWID integer not null,
     FIELDCNAME text not null,
     DESCRIPTION text not null
);

create table CONFIGSETTINGS (
     CONFIGFIELDID integer not null,
     DEVICEROWID integer not null,
     SETTINGCNAME text not null,
     DESCRIPTION text not null,
     BITMASK integer not null,
     BITVALUE integer not null
);

pragma read_uncommitted = 1;

begin transaction;

insert into DEVICES values (
     null,
     421,              -- Device ID
     4,                -- Family ID
     'BAX2.0.1',    	-- Part Name
     2,                -- Bytes Per Word (FLASH)
     32,               -- Write FLASH Block Size
     64,               -- Erase FLASH Page Size
     0,                -- Start of FLASH
     32768,            -- End of FLASH
     15728640,         -- Start of EEPROM
     15728896,         -- End of EEPROM
     262144,          -- Start of User ID
     262149,          -- End of User ID
     3145728,          -- Start of Config Bits
     3145742,          -- End of Config Bits
     4194302,          -- Start of Device Id
     4194304,          -- End of Device Id
     65504,            -- Device Id Mask
     0,                -- Start of GPR
     1088              -- End of GPR
);

insert into CONFIGWORDS values (
     NULL,
     (select max(ROWID) from DEVICES),
     'CONFIG1H',       -- Config Name
     3145729,          -- Address
     7,                -- Default Value
     207               -- Implemented Bits
);
insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'FOSC',           -- C Name
     'Oscillator Selection bits'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'RC',             -- C Name
     '11XX External RC oscillator, CLKOUT function on RA6',-- Description
     12,               -- Bit Mask
     12                -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'RC',             -- C Name
     '101X External RC oscillator, CLKOUT function on RA6',-- Description
     14,               -- Bit Mask
     10                -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'INTIO7',         -- C Name
     'Internal oscillator block, CLKOUT function on RA6, port function on RA7',-- Description
     15,               -- Bit Mask
     9                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'INTIO67',        -- C Name
     'Internal oscillator block, port function on RA6 and RA7',-- Description
     15,               -- Bit Mask
     8                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'RCIO6',          -- C Name
     'External RC oscillator, port function on RA6',-- Description
     15,               -- Bit Mask
     7                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'HSPLL',          -- C Name
     'HS oscillator, PLL enabled (Clock Frequency = 4 x FOSC1)',-- Description
     15,               -- Bit Mask
     6                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ECIO6',          -- C Name
     'EC oscillator, port function on RA6',-- Description
     15,               -- Bit Mask
     5                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'EC',             -- C Name
     'EC oscillator, CLKOUT function on RA6',-- Description
     15,               -- Bit Mask
     4                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'RC',             -- C Name
     'External RC oscillator, CLKOUT function on RA6',-- Description
     15,               -- Bit Mask
     3                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'HS',             -- C Name
     'HS oscillator',  -- Description
     15,               -- Bit Mask
     2                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'XT',             -- C Name
     'XT oscillator',  -- Description
     15,               -- Bit Mask
     1                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'LP',             -- C Name
     'LP oscillator',  -- Description
     15,               -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'FCMEN',          -- C Name
     'Fail-Safe Clock Monitor Enable bit'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'Fail-Safe Clock Monitor enabled',-- Description
     64,               -- Bit Mask
     64                -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'Fail-Safe Clock Monitor disabled',-- Description
     64,               -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'IESO',           -- C Name
     'Internal/External Oscillator Switchover bit'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'Oscillator Switchover mode enabled',-- Description
     128,              -- Bit Mask
     128               -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'Oscillator Switchover mode disabled',-- Description
     128,              -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGWORDS values (
     NULL,
     (select max(ROWID) from DEVICES),
     'CONFIG2L',       -- Config Name
     3145730,          -- Address
     31,               -- Default Value
     31                -- Implemented Bits
);
insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'PWRT',           -- C Name
     'Power-up Timer Enable bit'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'PWRT disabled',  -- Description
     1,                -- Bit Mask
     1                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'PWRT enabled',   -- Description
     1,                -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'BOREN',          -- C Name
     'Brown-out Reset Enable bits'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'SBORDIS',        -- C Name
     'Brown-out Reset enabled in hardware only (SBOREN is disabled)',-- Description
     6,                -- Bit Mask
     6                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'NOSLP',          -- C Name
     'Brown-out Reset enabled in hardware only and disabled in Sleep mode (SBOREN is disabled)',-- Description
     6,                -- Bit Mask
     4                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'Brown-out Reset enabled and controlled by software (SBOREN is enabled)',-- Description
     6,                -- Bit Mask
     2                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'Brown-out Reset disabled in hardware and software',-- Description
     6,                -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'BORV',           -- C Name
     'Brown Out Reset Voltage bits'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     '18',             -- C Name
     'VBOR set to 1.8 V nominal',-- Description
     24,               -- Bit Mask
     24                -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     '22',             -- C Name
     'VBOR set to 2.2 V nominal',-- Description
     24,               -- Bit Mask
     16                -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     '27',             -- C Name
     'VBOR set to 2.7 V nominal',-- Description
     24,               -- Bit Mask
     8                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     '30',             -- C Name
     'VBOR set to 3.0 V nominal',-- Description
     24,               -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGWORDS values (
     NULL,
     (select max(ROWID) from DEVICES),
     'CONFIG2H',       -- Config Name
     3145731,          -- Address
     31,               -- Default Value
     31                -- Implemented Bits
);
insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'WDTEN',          -- C Name
     'Watchdog Timer Enable bit'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'WDT is always enabled. SWDTEN bit has no effect',-- Description
     1,                -- Bit Mask
     1                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'WDT is controlled by SWDTEN bit of the WDTCON register',-- Description
     1,                -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'WDTPS',          -- C Name
     'Watchdog Timer Postscale Select bits'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     '32768',          -- C Name
     '1:32768',        -- Description
     30,               -- Bit Mask
     30                -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     '16384',          -- C Name
     '1:16384',        -- Description
     30,               -- Bit Mask
     28                -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     '8192',           -- C Name
     '1:8192',         -- Description
     30,               -- Bit Mask
     26                -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     '4096',           -- C Name
     '1:4096',         -- Description
     30,               -- Bit Mask
     24                -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     '2048',           -- C Name
     '1:2048',         -- Description
     30,               -- Bit Mask
     22                -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     '1024',           -- C Name
     '1:1024',         -- Description
     30,               -- Bit Mask
     20                -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     '512',            -- C Name
     '1:512',          -- Description
     30,               -- Bit Mask
     18                -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     '256',            -- C Name
     '1:256',          -- Description
     30,               -- Bit Mask
     16                -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     '128',            -- C Name
     '1:128',          -- Description
     30,               -- Bit Mask
     14                -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     '64',             -- C Name
     '1:64',           -- Description
     30,               -- Bit Mask
     12                -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     '32',             -- C Name
     '1:32',           -- Description
     30,               -- Bit Mask
     10                -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     '16',             -- C Name
     '1:16',           -- Description
     30,               -- Bit Mask
     8                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     '8',              -- C Name
     '1:8',            -- Description
     30,               -- Bit Mask
     6                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     '4',              -- C Name
     '1:4',            -- Description
     30,               -- Bit Mask
     4                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     '2',              -- C Name
     '1:2',            -- Description
     30,               -- Bit Mask
     2                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     '1',              -- C Name
     '1:1',            -- Description
     30,               -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGWORDS values (
     NULL,
     (select max(ROWID) from DEVICES),
     'CONFIG3H',       -- Config Name
     3145733,          -- Address
     139,              -- Default Value
     143               -- Implemented Bits
);
insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'CCP2MX',         -- C Name
     'CCP2 MUX bit'    -- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'PORTC',          -- C Name
     'CCP2 input/output is multiplexed with RC1',-- Description
     1,                -- Bit Mask
     1                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'PORTBE',         -- C Name
     'CCP2 input/output is multiplexed with RB3',-- Description
     1,                -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'PBADEN',         -- C Name
     'PORTB A/D Enable bit'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'PORTB<4:0> pins are configured as analog input channels on Reset',-- Description
     2,                -- Bit Mask
     2                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'PORTB<4:0> pins are configured as digital I/O on Reset',-- Description
     2,                -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'LPT1OSC',        -- C Name
     'Low-Power Timer1 Oscillator Enable bit'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'Timer1 configured for low-power operation',-- Description
     4,                -- Bit Mask
     4                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'Timer1 configured for higher power operation',-- Description
     4,                -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'HFOFST',         -- C Name
     'HFINTOSC Fast Start-up'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'HFINTOSC starts clocking the CPU without waiting for the oscillator to stablize.',-- Description
     8,                -- Bit Mask
     8                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'The system clock is held off until the HFINTOSC is stable.',-- Description
     8,                -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'MCLRE',          -- C Name
     'MCLR Pin Enable bit'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'MCLR pin enabled; RE3 input pin disabled',-- Description
     128,              -- Bit Mask
     128               -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'RE3 input pin enabled; MCLR disabled',-- Description
     128,              -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGWORDS values (
     NULL,
     (select max(ROWID) from DEVICES),
     'CONFIG4L',       -- Config Name
     3145734,          -- Address
     133,              -- Default Value
     197               -- Implemented Bits
);
insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'STVREN',         -- C Name
     'Stack Full/Underflow Reset Enable bit'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'Stack full/underflow will cause Reset',-- Description
     1,                -- Bit Mask
     1                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'Stack full/underflow will not cause Reset',-- Description
     1,                -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'LVP',            -- C Name
     'Single-Supply ICSP Enable bit'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'Single-Supply ICSP enabled',-- Description
     4,                -- Bit Mask
     4                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'Single-Supply ICSP disabled',-- Description
     4,                -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'XINST',          -- C Name
     'Extended Instruction Set Enable bit'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'Instruction set extension and Indexed Addressing mode enabled',-- Description
     64,               -- Bit Mask
     64                -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'Instruction set extension and Indexed Addressing mode disabled (Legacy mode)',-- Description
     64,               -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'DEBUG',          -- C Name
     'Background Debugger Enable bit'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'Background debugger disabled, RB6 and RB7 configured as general purpose I/O pins',-- Description
     128,              -- Bit Mask
     128               -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'Background debugger enabled, RB6 and RB7 are dedicated to In-Circuit Debug',-- Description
     128,              -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGWORDS values (
     NULL,
     (select max(ROWID) from DEVICES),
     'CONFIG5L',       -- Config Name
     3145736,          -- Address
     15,               -- Default Value
     15                -- Implemented Bits
);
insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'CP0',            -- C Name
     'Code Protection Block 0'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'Block 0 (000800-001FFFh) not code-protected',-- Description
     1,                -- Bit Mask
     1                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'Block 0 (000800-001FFFh) code-protected',-- Description
     1,                -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'CP1',            -- C Name
     'Code Protection Block 1'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'Block 1 (002000-003FFFh) not code-protected',-- Description
     2,                -- Bit Mask
     2                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'Block 1 (002000-003FFFh) code-protected',-- Description
     2,                -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'CP2',            -- C Name
     'Code Protection Block 2'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'Block 2 (004000-005FFFh) not code-protected',-- Description
     4,                -- Bit Mask
     4                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'Block 2 (004000-005FFFh) code-protected',-- Description
     4,                -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'CP3',            -- C Name
     'Code Protection Block 3'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'Block 3 (006000-007FFFh) not code-protected',-- Description
     8,                -- Bit Mask
     8                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'Block 3 (006000-007FFFh) code-protected',-- Description
     8,                -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGWORDS values (
     NULL,
     (select max(ROWID) from DEVICES),
     'CONFIG5H',       -- Config Name
     3145737,          -- Address
     192,              -- Default Value
     192               -- Implemented Bits
);
insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'CPB',            -- C Name
     'Boot Block Code Protection bit'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'Boot block (000000-0007FFh) not code-protected',-- Description
     64,               -- Bit Mask
     64                -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'Boot block (000000-0007FFh) code-protected',-- Description
     64,               -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'CPD',            -- C Name
     'Data EEPROM Code Protection bit'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'Data EEPROM not code-protected',-- Description
     128,              -- Bit Mask
     128               -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'Data EEPROM code-protected',-- Description
     128,              -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGWORDS values (
     NULL,
     (select max(ROWID) from DEVICES),
     'CONFIG6L',       -- Config Name
     3145738,          -- Address
     15,               -- Default Value
     15                -- Implemented Bits
);
insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'WRT0',           -- C Name
     'Write Protection Block 0'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'Block 0 (000800-001FFFh) not write-protected',-- Description
     1,                -- Bit Mask
     1                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'Block 0 (000800-001FFFh) write-protected',-- Description
     1,                -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'WRT1',           -- C Name
     'Write Protection Block 1'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'Block 1 (002000-003FFFh) not write-protected',-- Description
     2,                -- Bit Mask
     2                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'Block 1 (002000-003FFFh) write-protected',-- Description
     2,                -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'WRT2',           -- C Name
     'Write Protection Block 2'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'Block 2 (004000-005FFFh) not write-protected',-- Description
     4,                -- Bit Mask
     4                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'Block 2 (004000-005FFFh) write-protected',-- Description
     4,                -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'WRT3',           -- C Name
     'Write Protection Block 3'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'Block 3 (006000-007FFFh) not write-protected',-- Description
     8,                -- Bit Mask
     8                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'Block 3 (006000-007FFFh) write-protected',-- Description
     8,                -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGWORDS values (
     NULL,
     (select max(ROWID) from DEVICES),
     'CONFIG6H',       -- Config Name
     3145739,          -- Address
     224,              -- Default Value
     224               -- Implemented Bits
);
insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'WRTC',           -- C Name
     'Configuration Register Write Protection bit'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'Configuration registers (300000-3000FFh) not write-protected',-- Description
     32,               -- Bit Mask
     32                -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'Configuration registers (300000-3000FFh) write-protected',-- Description
     32,               -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'WRTB',           -- C Name
     'Boot Block Write Protection bit'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'Boot Block (000000-0007FFh) not write-protected',-- Description
     64,               -- Bit Mask
     64                -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'Boot Block (000000-0007FFh) write-protected',-- Description
     64,               -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'WRTD',           -- C Name
     'Data EEPROM Write Protection bit'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'Data EEPROM not write-protected',-- Description
     128,              -- Bit Mask
     128               -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'Data EEPROM write-protected',-- Description
     128,              -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGWORDS values (
     NULL,
     (select max(ROWID) from DEVICES),
     'CONFIG7L',       -- Config Name
     3145740,          -- Address
     15,               -- Default Value
     15                -- Implemented Bits
);
insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'EBTR0',          -- C Name
     'Table Read Protection Block 0'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'Block 0 (000800-001FFFh) not protected from table reads executed in other blocks',-- Description
     1,                -- Bit Mask
     1                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'Block 0 (000800-001FFFh) protected from table reads executed in other blocks',-- Description
     1,                -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'EBTR1',          -- C Name
     'Table Read Protection Block 1'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'Block 1 (002000-003FFFh) not protected from table reads executed in other blocks',-- Description
     2,                -- Bit Mask
     2                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'Block 1 (002000-003FFFh) protected from table reads executed in other blocks',-- Description
     2,                -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'EBTR2',          -- C Name
     'Table Read Protection Block 2'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'Block 2 (004000-005FFFh) not protected from table reads executed in other blocks',-- Description
     4,                -- Bit Mask
     4                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'Block 2 (004000-005FFFh) protected from table reads executed in other blocks',-- Description
     4,                -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'EBTR3',          -- C Name
     'Table Read Protection Block 3'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'Block 3 (006000-007FFFh) not protected from table reads executed in other blocks',-- Description
     8,                -- Bit Mask
     8                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'Block 3 (006000-007FFFh) protected from table reads executed in other blocks',-- Description
     8,                -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGWORDS values (
     NULL,
     (select max(ROWID) from DEVICES),
     'CONFIG7H',       -- Config Name
     3145741,          -- Address
     64,               -- Default Value
     64                -- Implemented Bits
);
insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'EBTRB',          -- C Name
     'Boot Block Table Read Protection bit'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'Boot Block (000000-0007FFh) not protected from table reads executed in other blocks',-- Description
     64,               -- Bit Mask
     64                -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'Boot Block (000000-0007FFh) protected from table reads executed in other blocks',-- Description
     64,               -- Bit Mask
     0                 -- Bit Value
);


insert into DEVICES values (
     null,
     420,              -- Device ID
     4,                -- Family ID
     'BAX2.0.0',    -- Part Name
     2,                -- Bytes Per Word (FLASH)
     64,               -- Write FLASH Block Size
     64,               -- Erase FLASH Page Size
     0,                -- Start of FLASH
     65536,            -- End of FLASH
     15728640,         -- Start of EEPROM
     15729664,         -- End of EEPROM
     262144,          -- Start of User ID
     262149,          -- End of User ID
     3145728,          -- Start of Config Bits
     3145742,          -- End of Config Bits
     4194302,          -- Start of Device Id
     4194304,          -- End of Device Id
     65504,            -- Device Id Mask
     0,                -- Start of GPR
     1088              -- End of GPR
);
insert into CONFIGWORDS values (
     NULL,
     (select max(ROWID) from DEVICES),
     'CONFIG1H',       -- Config Name
     3145729,          -- Address
     7,                -- Default Value
     207               -- Implemented Bits
);
insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'FOSC',           -- C Name
     'Oscillator Selection bits'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'RC',             -- C Name
     '11XX External RC oscillator, CLKOUT function on RA6',-- Description
     12,               -- Bit Mask
     12                -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'RC',             -- C Name
     '101X External RC oscillator, CLKOUT function on RA6',-- Description
     14,               -- Bit Mask
     10                -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'INTIO7',         -- C Name
     'Internal oscillator block, CLKOUT function on RA6, port function on RA7',-- Description
     15,               -- Bit Mask
     9                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'INTIO67',        -- C Name
     'Internal oscillator block, port function on RA6 and RA7',-- Description
     15,               -- Bit Mask
     8                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'RCIO6',          -- C Name
     'External RC oscillator, port function on RA6',-- Description
     15,               -- Bit Mask
     7                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'HSPLL',          -- C Name
     'HS oscillator, PLL enabled (Clock Frequency = 4 x FOSC1)',-- Description
     15,               -- Bit Mask
     6                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ECIO6',          -- C Name
     'EC oscillator, port function on RA6',-- Description
     15,               -- Bit Mask
     5                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'EC',             -- C Name
     'EC oscillator, CLKOUT function on RA6',-- Description
     15,               -- Bit Mask
     4                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'RC',             -- C Name
     'External RC oscillator, CLKOUT function on RA6',-- Description
     15,               -- Bit Mask
     3                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'HS',             -- C Name
     'HS oscillator',  -- Description
     15,               -- Bit Mask
     2                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'XT',             -- C Name
     'XT oscillator',  -- Description
     15,               -- Bit Mask
     1                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'LP',             -- C Name
     'LP oscillator',  -- Description
     15,               -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'FCMEN',          -- C Name
     'Fail-Safe Clock Monitor Enable bit'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'Fail-Safe Clock Monitor enabled',-- Description
     64,               -- Bit Mask
     64                -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'Fail-Safe Clock Monitor disabled',-- Description
     64,               -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'IESO',           -- C Name
     'Internal/External Oscillator Switchover bit'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'Oscillator Switchover mode enabled',-- Description
     128,              -- Bit Mask
     128               -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'Oscillator Switchover mode disabled',-- Description
     128,              -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGWORDS values (
     NULL,
     (select max(ROWID) from DEVICES),
     'CONFIG2L',       -- Config Name
     3145730,          -- Address
     31,               -- Default Value
     31                -- Implemented Bits
);
insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'PWRT',           -- C Name
     'Power-up Timer Enable bit'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'PWRT disabled',  -- Description
     1,                -- Bit Mask
     1                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'PWRT enabled',   -- Description
     1,                -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'BOREN',          -- C Name
     'Brown-out Reset Enable bits'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'SBORDIS',        -- C Name
     'Brown-out Reset enabled in hardware only (SBOREN is disabled)',-- Description
     6,                -- Bit Mask
     6                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'NOSLP',          -- C Name
     'Brown-out Reset enabled in hardware only and disabled in Sleep mode (SBOREN is disabled)',-- Description
     6,                -- Bit Mask
     4                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'Brown-out Reset enabled and controlled by software (SBOREN is enabled)',-- Description
     6,                -- Bit Mask
     2                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'Brown-out Reset disabled in hardware and software',-- Description
     6,                -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'BORV',           -- C Name
     'Brown Out Reset Voltage bits'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     '18',             -- C Name
     'VBOR set to 1.8 V nominal',-- Description
     24,               -- Bit Mask
     24                -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     '22',             -- C Name
     'VBOR set to 2.2 V nominal',-- Description
     24,               -- Bit Mask
     16                -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     '27',             -- C Name
     'VBOR set to 2.7 V nominal',-- Description
     24,               -- Bit Mask
     8                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     '30',             -- C Name
     'VBOR set to 3.0 V nominal',-- Description
     24,               -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGWORDS values (
     NULL,
     (select max(ROWID) from DEVICES),
     'CONFIG2H',       -- Config Name
     3145731,          -- Address
     31,               -- Default Value
     31                -- Implemented Bits
);
insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'WDTEN',          -- C Name
     'Watchdog Timer Enable bit'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'WDT is always enabled. SWDTEN bit has no effect',-- Description
     1,                -- Bit Mask
     1                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'WDT is controlled by SWDTEN bit of the WDTCON register',-- Description
     1,                -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'WDTPS',          -- C Name
     'Watchdog Timer Postscale Select bits'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     '32768',          -- C Name
     '1:32768',        -- Description
     30,               -- Bit Mask
     30                -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     '16384',          -- C Name
     '1:16384',        -- Description
     30,               -- Bit Mask
     28                -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     '8192',           -- C Name
     '1:8192',         -- Description
     30,               -- Bit Mask
     26                -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     '4096',           -- C Name
     '1:4096',         -- Description
     30,               -- Bit Mask
     24                -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     '2048',           -- C Name
     '1:2048',         -- Description
     30,               -- Bit Mask
     22                -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     '1024',           -- C Name
     '1:1024',         -- Description
     30,               -- Bit Mask
     20                -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     '512',            -- C Name
     '1:512',          -- Description
     30,               -- Bit Mask
     18                -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     '256',            -- C Name
     '1:256',          -- Description
     30,               -- Bit Mask
     16                -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     '128',            -- C Name
     '1:128',          -- Description
     30,               -- Bit Mask
     14                -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     '64',             -- C Name
     '1:64',           -- Description
     30,               -- Bit Mask
     12                -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     '32',             -- C Name
     '1:32',           -- Description
     30,               -- Bit Mask
     10                -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     '16',             -- C Name
     '1:16',           -- Description
     30,               -- Bit Mask
     8                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     '8',              -- C Name
     '1:8',            -- Description
     30,               -- Bit Mask
     6                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     '4',              -- C Name
     '1:4',            -- Description
     30,               -- Bit Mask
     4                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     '2',              -- C Name
     '1:2',            -- Description
     30,               -- Bit Mask
     2                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     '1',              -- C Name
     '1:1',            -- Description
     30,               -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGWORDS values (
     NULL,
     (select max(ROWID) from DEVICES),
     'CONFIG3H',       -- Config Name
     3145733,          -- Address
     139,              -- Default Value
     143               -- Implemented Bits
);
insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'CCP2MX',         -- C Name
     'CCP2 MUX bit'    -- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'PORTC',          -- C Name
     'CCP2 input/output is multiplexed with RC1',-- Description
     1,                -- Bit Mask
     1                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'PORTBE',         -- C Name
     'CCP2 input/output is multiplexed with RB3',-- Description
     1,                -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'PBADEN',         -- C Name
     'PORTB A/D Enable bit'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'PORTB<4:0> pins are configured as analog input channels on Reset',-- Description
     2,                -- Bit Mask
     2                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'PORTB<4:0> pins are configured as digital I/O on Reset',-- Description
     2,                -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'LPT1OSC',        -- C Name
     'Low-Power Timer1 Oscillator Enable bit'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'Timer1 configured for low-power operation',-- Description
     4,                -- Bit Mask
     4                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'Timer1 configured for higher power operation',-- Description
     4,                -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'HFOFST',         -- C Name
     'HFINTOSC Fast Start-up'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'HFINTOSC starts clocking the CPU without waiting for the oscillator to stablize.',-- Description
     8,                -- Bit Mask
     8                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'The system clock is held off until the HFINTOSC is stable.',-- Description
     8,                -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'MCLRE',          -- C Name
     'MCLR Pin Enable bit'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'MCLR pin enabled; RE3 input pin disabled',-- Description
     128,              -- Bit Mask
     128               -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'RE3 input pin enabled; MCLR disabled',-- Description
     128,              -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGWORDS values (
     NULL,
     (select max(ROWID) from DEVICES),
     'CONFIG4L',       -- Config Name
     3145734,          -- Address
     133,              -- Default Value
     197               -- Implemented Bits
);
insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'STVREN',         -- C Name
     'Stack Full/Underflow Reset Enable bit'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'Stack full/underflow will cause Reset',-- Description
     1,                -- Bit Mask
     1                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'Stack full/underflow will not cause Reset',-- Description
     1,                -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'LVP',            -- C Name
     'Single-Supply ICSP Enable bit'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'Single-Supply ICSP enabled',-- Description
     4,                -- Bit Mask
     4                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'Single-Supply ICSP disabled',-- Description
     4,                -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'XINST',          -- C Name
     'Extended Instruction Set Enable bit'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'Instruction set extension and Indexed Addressing mode enabled',-- Description
     64,               -- Bit Mask
     64                -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'Instruction set extension and Indexed Addressing mode disabled (Legacy mode)',-- Description
     64,               -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'DEBUG',          -- C Name
     'Background Debugger Enable bit'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'Background debugger disabled, RB6 and RB7 configured as general purpose I/O pins',-- Description
     128,              -- Bit Mask
     128               -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'Background debugger enabled, RB6 and RB7 are dedicated to In-Circuit Debug',-- Description
     128,              -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGWORDS values (
     NULL,
     (select max(ROWID) from DEVICES),
     'CONFIG5L',       -- Config Name
     3145736,          -- Address
     15,               -- Default Value
     15                -- Implemented Bits
);
insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'CP0',            -- C Name
     'Code Protection Block 0'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'Block 0 (000800-003FFFh) not code-protected',-- Description
     1,                -- Bit Mask
     1                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'Block 0 (000800-003FFFh) code-protected',-- Description
     1,                -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'CP1',            -- C Name
     'Code Protection Block 1'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'Block 1 (004000-007FFFh) not code-protected',-- Description
     2,                -- Bit Mask
     2                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'Block 1 (004000-007FFFh) code-protected',-- Description
     2,                -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'CP2',            -- C Name
     'Code Protection Block 2'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'Block 2 (008000-00BFFFh) not code-protected',-- Description
     4,                -- Bit Mask
     4                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'Block 2 (008000-00BFFFh) code-protected',-- Description
     4,                -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'CP3',            -- C Name
     'Code Protection Block 3'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'Block 3 (00C000-00FFFFh) not code-protected',-- Description
     8,                -- Bit Mask
     8                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'Block 3 (00C000-00FFFFh) code-protected',-- Description
     8,                -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGWORDS values (
     NULL,
     (select max(ROWID) from DEVICES),
     'CONFIG5H',       -- Config Name
     3145737,          -- Address
     192,              -- Default Value
     192               -- Implemented Bits
);
insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'CPB',            -- C Name
     'Boot Block Code Protection bit'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'Boot block (000000-0007FFh) not code-protected',-- Description
     64,               -- Bit Mask
     64                -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'Boot block (000000-0007FFh) code-protected',-- Description
     64,               -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'CPD',            -- C Name
     'Data EEPROM Code Protection bit'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'Data EEPROM not code-protected',-- Description
     128,              -- Bit Mask
     128               -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'Data EEPROM code-protected',-- Description
     128,              -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGWORDS values (
     NULL,
     (select max(ROWID) from DEVICES),
     'CONFIG6L',       -- Config Name
     3145738,          -- Address
     15,               -- Default Value
     15                -- Implemented Bits
);
insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'WRT0',           -- C Name
     'Write Protection Block 0'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'Block 0 (000800-003FFFh) not write-protected',-- Description
     1,                -- Bit Mask
     1                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'Block 0 (000800-003FFFh) write-protected',-- Description
     1,                -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'WRT1',           -- C Name
     'Write Protection Block 1'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'Block 1 (004000-007FFFh) not write-protected',-- Description
     2,                -- Bit Mask
     2                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'Block 1 (004000-007FFFh) write-protected',-- Description
     2,                -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'WRT2',           -- C Name
     'Write Protection Block 2'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'Block 2 (008000-00BFFFh) not write-protected',-- Description
     4,                -- Bit Mask
     4                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'Block 2 (008000-00BFFFh) write-protected',-- Description
     4,                -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'WRT3',           -- C Name
     'Write Protection Block 3'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'Block 3 (00C000h-00FFFFh) not write-protected',-- Description
     8,                -- Bit Mask
     8                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'Block 3 (00C000h-00FFFFh) write-protected',-- Description
     8,                -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGWORDS values (
     NULL,
     (select max(ROWID) from DEVICES),
     'CONFIG6H',       -- Config Name
     3145739,          -- Address
     224,              -- Default Value
     224               -- Implemented Bits
);
insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'WRTC',           -- C Name
     'Configuration Register Write Protection bit'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'Configuration registers (300000-3000FFh) not write-protected',-- Description
     32,               -- Bit Mask
     32                -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'Configuration registers (300000-3000FFh) write-protected',-- Description
     32,               -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'WRTB',           -- C Name
     'Boot Block Write Protection bit'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'Boot Block (000000-0007FFh) not write-protected',-- Description
     64,               -- Bit Mask
     64                -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'Boot Block (000000-0007FFh) write-protected',-- Description
     64,               -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'WRTD',           -- C Name
     'Data EEPROM Write Protection bit'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'Data EEPROM not write-protected',-- Description
     128,              -- Bit Mask
     128               -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'Data EEPROM write-protected',-- Description
     128,              -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGWORDS values (
     NULL,
     (select max(ROWID) from DEVICES),
     'CONFIG7L',       -- Config Name
     3145740,          -- Address
     15,               -- Default Value
     15                -- Implemented Bits
);
insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'EBTR0',          -- C Name
     'Table Read Protection Block 0'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'Block 0 (000800-003FFFh) not protected from table reads executed in other blocks',-- Description
     1,                -- Bit Mask
     1                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'Block 0 (000800-003FFFh) protected from table reads executed in other blocks',-- Description
     1,                -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'EBTR1',          -- C Name
     'Table Read Protection Block 1'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'Block 1 (004000-007FFFh) not protected from table reads executed in other blocks',-- Description
     2,                -- Bit Mask
     2                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'Block 1 (004000-007FFFh) protected from table reads executed in other blocks',-- Description
     2,                -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'EBTR2',          -- C Name
     'Table Read Protection Block 2'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'Block 2 (008000-00BFFFh) not protected from table reads executed in other blocks',-- Description
     4,                -- Bit Mask
     4                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'Block 2 (008000-00BFFFh) protected from table reads executed in other blocks',-- Description
     4,                -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'EBTR3',          -- C Name
     'Table Read Protection Block 3'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'Block 3 (00C000-00FFFFh) not protected from table reads executed in other blocks',-- Description
     8,                -- Bit Mask
     8                 -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'Block 3 (00C000-00FFFFh) protected from table reads executed in other blocks',-- Description
     8,                -- Bit Mask
     0                 -- Bit Value
);

insert into CONFIGWORDS values (
     NULL,
     (select max(ROWID) from DEVICES),
     'CONFIG7H',       -- Config Name
     3145741,          -- Address
     64,               -- Default Value
     64                -- Implemented Bits
);
insert into CONFIGFIELDS values (
     NULL,
     (select max(ROWID) from CONFIGWORDS),
     (select max(ROWID) from DEVICES),
     'EBTRB',          -- C Name
     'Boot Block Table Read Protection bit'-- Description
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'OFF',            -- C Name
     'Boot Block (000000-0007FFh) not protected from table reads executed in other blocks',-- Description
     64,               -- Bit Mask
     64                -- Bit Value
);

insert into CONFIGSETTINGS values (
     (select max(ROWID) from CONFIGFIELDS),
     (select max(ROWID) from DEVICES),
     'ON',             -- C Name
     'Boot Block (000000-0007FFh) protected from table reads executed in other blocks',-- Description
     64,               -- Bit Mask
     0                 -- Bit Value
);


commit transaction;
