// OmmManager
/*
The OmmManager class enumerates potential connections, manages existing connections, and allows access to the local data store.  
  Promise<function(Array<OmmConnection>)> OmmManager.getConnections();

Lists potential connections to devices, returning an array of OmmConnection objects.
Two functions allow the application to register to be notified when a device is connected or disconnected.  
To set a callback function to be called when a new connection is discovered:
  void OmmManager.onConnectionAdded(callback:function(OmmConnection));
And, to set a callback function to be called when a connection is removed:
  void OmmManager.onConnectionRemoved(callback:function(OmmConnection));
The manager is used to obtain a reference to the data store:
  Promise<function(OmmStore)> OmmManager.getStore(storeParameters:Object);
Where storeParameters can be null, and is reserved for future use.
*/

var OmmManager = (function () {
	var manager = {};
	//var privateVariable = 1;
    
	// function privateMethod() { ; }
    
	//manager.moduleProperty = 1;
	
	manager.domain = "http://127.0.0.1:1234";	// "http://localhost:1234";
	
	
	var previewImageUrl = function(filename, path, previewParameters) {
		var url = "" + manager.getDomain("http") + "/preview?file=" + encodeURIComponent(filename);
		if (path != null)
		{
			url = url + "&path=" + encodeURIComponent(path) + "";
		}
		if (previewParameters != null && typeof previewParameters.width != 'undefined') { url = url + "&width=" + encodeURIComponent(previewParameters.width) + ""; }
		if (previewParameters != null && typeof previewParameters.height != 'undefined') { url = url + "&height=" + encodeURIComponent(previewParameters.height) + ""; }
		if (previewParameters != null && typeof previewParameters.start != 'undefined') { url = url + "&start=" + encodeURIComponent(previewParameters.start) + ""; }
		if (previewParameters != null && typeof previewParameters.end   != 'undefined') { url = url + "&end="   + encodeURIComponent(previewParameters.end)   + ""; }
		if (previewParameters != null && typeof previewParameters.accel != 'undefined' && !previewParameters.accel) { url = url + "&accel=0"; } else  { url = url + "&accel=1"; }
		if (previewParameters != null && typeof previewParameters.gyro  != 'undefined' && previewParameters.gyro)  { url = url + "&gyro=1"; }
		if (previewParameters != null && typeof previewParameters.mag   != 'undefined' && previewParameters.mag)   { url = url + "&mag=1"; }
		if (previewParameters != null && typeof previewParameters.temp  != 'undefined' && previewParameters.temp)  { url = url + "&temp=1"; }
		if (previewParameters != null && typeof previewParameters.light != 'undefined' && previewParameters.light) { url = url + "&light=1"; }		
		if (previewParameters != null && typeof previewParameters.pres  != 'undefined' && previewParameters.pres)  { url = url + "&pres=1"; }		
		if (previewParameters != null && typeof previewParameters.batt  != 'undefined' && previewParameters.batt)  { url = url + "&batt=1"; }		
		if (previewParameters != null && typeof previewParameters.annotations != 'undefined' && previewParameters.annotations) { url = url + "&annotations=1"; }		
		return url;
	};

	var getMetadataAdvanced = function(filename, path, metadataParameters, callbackSuccess, callbackFailure) {
		var url = "" + manager.getDomain("http") + "/metadata?file=" + encodeURIComponent(filename);
		if (path != null)
		{
			url = url + "&path=" + encodeURIComponent(path) + "";
		}
		if (metadataParameters != null && typeof metadataParameters.annotations && metadataParameters.annotations)
		{
			url = url + "&annotations=1";
		}
		
		// AJAX request
		var xmlhttp;
		xmlhttp = (window.XMLHttpRequest) ? (new XMLHttpRequest()) : (new ActiveXObject("Microsoft.XMLHTTP"));
		xmlhttp.onreadystatechange = function() {
			if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
			{
				var response = (JSON && JSON.parse) ? JSON.parse(xmlhttp.responseText) : eval('(' + xmlhttp.responseText + ')');
				
				// Transform OmmMetadata.annotations[].timestamps
				//if (typeof response.annotations.timestamp !== 'undefined') { response.annotations.timestamp = new Date(response.annotations.timestamp * 1000); }
				
				// Pass response through
				if (callbackSuccess) { callbackSuccess(response); }
			}
			else if (xmlhttp.readyState == 4)
			{
				if (callbackFailure) { callbackFailure(); }
			}
		}
		xmlhttp.open("GET", url, true);
		xmlhttp.send();		
	}
	
	
	// OmmCommand
	var OmmCommand = function(transmit, expectedPrefix, timeout, callbackSuccess, callbackFailure) {
		var command = {};
		
		// NOTE: line-by-line parsing, any line starting "ERROR:" signifies failure, incoming buffer flushed.
		
		// Parameters
		command.transmit = transmit;
		command.expectedPrefix = expectedPrefix;
		command.timeout = timeout;
		command.callbackSuccess = callbackSuccess;
		command.callbackFailure = callbackFailure;
		command.complete = false;
		
		// 
		command.begin = function(callbackSelfRemove) {
			// TODO: Timeouts?
			setTimeout(function() {
				if (!command.complete) {
					command.complete = true;
					if (callbackSelfRemove) { callbackSelfRemove(); }
					if (callbackFailure) { callbackFailure(); }
				}
			}, command.timeout);
			return command.transmit;
		}
		
		// 
		command.processLine = function(line) {
		
			var expectedIsArray = (Object.prototype.toString.call(command.expectedPrefix) == "[object Array]");
			var wasExpected = false;
			
			if (expectedIsArray) {
			    for (i = 0; i < command.expectedPrefix.length; i++) {
//console.log("EXPECTING " + i + ": " + command.expectedPrefix[i]);
					if (line.indexOf(command.expectedPrefix[i]) === 0) { wasExpected = true; break; }
				}
			} else {
//console.log("EXPECTING: " + command.expectedPrefix);
				if (line.indexOf(command.expectedPrefix) === 0) { wasExpected = true; }
			}
			
//console.log("IN: " + line + (wasExpected ? " [EXPECTED]" : ""));
		
			if (wasExpected) {
				if (callbackSuccess) { 
					if (callbackSuccess(line)) { command.complete = true; }
				}
				else { command.complete = true; }
			} else if (line.indexOf("ERROR:") === 0) {
				command.complete = true;
				if (callbackFailure) { callbackFailure(); }
			}
			
			return command.complete;
		}
		
		return command;
	}

	
	// OmmConnection
	var OmmConnection = function(portInfo) {
		var connection = {};
		
		// Copy fields
		connection.type = portInfo.type;
		connection.port = portInfo.port;
		if (portInfo.serial) { connection.serial = portInfo.serial; }
		if (portInfo.id) { connection.id = portInfo.id; }
		if (portInfo.path) { connection.path = portInfo.path; }
		if (portInfo.mac) { connection.mac = portInfo.mac; }
		
		// Connection information
		connection.websocket = null;
		// Command queue
		connection.commandQueue = [];
		// Buffered input
		connection.inputBuffer = "";
		// Input mode
		connection.inSlip = false;
		connection.slipEscaped = false;
		// Received handler
		connection.receivedHandler = null;
		connection.onReceived = function(handler) { connection.receivedHandler = handler; }
	
		
		// OmmConnection.runNextCommand
		function runNextCommand() {
			// Drain buffer
			// NOTE: Will only want to drain text lines if streaming (keep separate from binary streams and known lines relating to the streams)
			connection.inputBuffer = "";
			
			// If we have another command pending
			if (connection.commandQueue.length > 0) {
				var command = connection.commandQueue[0];
				
				var output = command.begin(function() {
					// Timeout error - remove command from queue
					connection.commandQueue.splice(0, 1);
					
					// Start next command
					runNextCommand();					
				});
				if (connection.websocket != null) {
console.log("SEND: " + output);
					connection.websocket.send(output);
				} else {
console.log("ERROR: WebSocket not connected ('" + connection.port + "'), cannot send command: " + output);
				}
				
			}
		}
		
		function queueCommand(command) {
			var runNow = (connection.commandQueue.length == 0);
			connection.commandQueue[connection.commandQueue.length] = command;
			if (runNow) { runNextCommand(); }
		}
		
		function receivedLine(line, binary) {
			// If we have a command pending
			if (connection.commandQueue.length > 0) {
				var command = connection.commandQueue[0];
//console.log("IN (" + command.expectedPrefix + "): " + line);
				// Process the line, return true if command completed (success or fail)
				if (command.processLine(line)) {
					// Remove command from queue
					connection.commandQueue.splice(0, 1);
					
					// Start next command
					runNextCommand();
				}
				else if (connection.receivedHandler != null) { connection.receivedHandler(connection, line, binary); }
				else if (manager.receivedHandler != null) { manager.receivedHandler(connection, line, binary); }
				else { console.log("RECV (unhandled): " + line); }
			}	
			else if (connection.receivedHandler != null) { connection.receivedHandler(connection, line, binary); }
			else if (manager.receivedHandler != null) { manager.receivedHandler(connection, line, binary); }
			else { console.log("RECV (unhandled): " + line); }
		}
		
		function receivedData(data) {
		
//console.log("BUFFER: " + connection.inputBuffer + "|" + data);
			
			// SLIP codes
			var SLIP_END = 0xC0;                   // 192 End of packet indicator
			var SLIP_ESC = 0xDB;                   // 219 Escape character, next character will be a substitution
			var SLIP_ESC_END = 0xDC;               // 220 Escaped substitution for the END data byte
			var SLIP_ESC_ESC = 0xDD;               // 221 Escaped substitution for the ESC data byte
		
			// Parse incoming data
			var i;
			for (i = 0; i < data.length; i++) {
				var endOfPacket = false;
				var binary = false;
				var b = data[i];
				
				if (connection.inSlip)	// If SLIP parsing
				{
					// If SLIP packet too large, junk it...
					if (connection.inputBuffer.length > 512)
					{
						connection.inputBuffer = "";
						connection.inSlip = false;
						connection.slipEscaped = false;
					}
					else if (b == SLIP_END)
					{
						if (connection.slipEscaped) { console.log("Unexpected escaped SLIP_END."); }
						connection.slipEscaped = false;
						endOfPacket = true;
						binary = true;
					}
					else if (b == SLIP_ESC)
					{
						if (connection.slipEscaped) { console.log("Unexpected escaped SLIP_ESC."); }
						connection.slipEscaped = true;
					}
                    else if (connection.slipEscaped && b == 10) 	// Special escape
                    { 
                        endOfPacket = true; 
                        connection.inSlip = false;
                        connection.slipEscaped = false;
						binary = true;
                    }
					else		// Add a byte to the buffer...
					{
                        // Translate a byte if escaped
                        if (connection.slipEscaped)
                        {
                            if (b == SLIP_ESC_ESC) { b = SLIP_ESC; }
                            else if (b == SLIP_ESC_END) { b = SLIP_END; }
                            else { console.log("WARNING: Unexpected escaped character (" + b + ")"); }
                            connection.slipEscaped = false;
                        }
                        connection.inputBuffer = connection.inputBuffer + b;
					}
				}
				else 	// If text parsing...
				{
                    if (b == '\r' || b == '\n') { endOfPacket = true; }
                    else if (b == SLIP_END) { connection.inSlip = true; connection.slipEscaped = false; endOfPacket = true; }
                    else { connection.inputBuffer = connection.inputBuffer + b; }				
				}
				
				// Line/packet received
				if (endOfPacket)
				{
					// Consume line from buffer
					var line = connection.inputBuffer;					
					connection.inputBuffer = "";
					
					//console.log("LINE: " + line);

					// Handle non-empty lines
					if (line.length > 0)
					{					
						receivedLine(line, binary);
					}
				}

			}
		}

		
		function parseDateTime(dateString)
		{
			if (dateString == "0") { return 0; }	// Infinitely early
			if (dateString == "-1") { return -1; }	// Infinitely late
			var year   = parseInt(dateString.substring(0,4));
			var month  = parseInt(dateString.substring(5,7));
			var day    = parseInt(dateString.substring(8,10));
			var hour   = parseInt(dateString.substring(11,13));
			var minute = parseInt(dateString.substring(14,16));
			var second = parseInt(dateString.substring(17,19));
			var date = new Date(year, month-1, day, hour, minute, second, 0);
			return date;
		}
		
		function packDateTime(newTime) {
			if (newTime === null) { newTime = new Date(); }
			if (newTime == 0) { return "0"; }		// Infinitely early
			if (newTime == -1) { return "-1"; }	// Infinitely late
			var timestr = newTime.getFullYear() + "-";
			timestr = timestr + ((newTime.getMonth() + 1 < 10) ? "0" : "") + (newTime.getMonth() + 1) + "-";
			timestr = timestr + ((newTime.getDate() < 10) ? "0" : "") + newTime.getDate() + ",";
			timestr = timestr + ((newTime.getHours() < 10) ? "0" : "") + newTime.getHours() + ":";
			timestr = timestr + ((newTime.getMinutes() < 10) ? "0" : "") + newTime.getMinutes() + ":";
			timestr = timestr + ((newTime.getSeconds() < 10) ? "0" : "") + newTime.getSeconds() + "";
			return timestr;
		}

		
		// OmmConnection.open();
		connection.open = function(callbackSuccess, callbackFailure) {
			
			// Close if currently open
			if (connection.websocket) {
				connection.close();
			}
			
			
			var wsUri = OmmManager.getConnectionUrl() + connection.port;
			
console.log("Creating WebSocket object for port '" + connection.port + "': " + wsUri);
			connection.websocket = new WebSocket(wsUri);
			
			//connection.websocket.binaryType = "blob";
			connection.websocket.binaryType = "arraybuffer";			
			
			connection.websocket.onopen = function(evt) { 
				if (callbackSuccess) { callbackSuccess(); } 
			};
			
			connection.websocket.onclose = function(evt) {
				// TODO: onClose
				;
				connection.websocket = null;
				connection.commandQueue = [];
				connection.inputBuffer = "";
			};
			
			// Buffer incoming port data
			connection.websocket.onmessage = function(evt) {
//console.log("]]] " + evt.data);
				var data = evt.data
				
				// Treat binary data as 8-bit ASCII
				if (data instanceof ArrayBuffer) {
					var bytearray = new Uint8Array(data);
					var i, len = bytearray.length;
					var result = '';
					for (i = 0; i < len; i++) {
					    result += String.fromCharCode(bytearray[i]);
					}
					data = result;
				} 
				
				receivedData(data);
			};
			
			// Error calls failure callback (replace after open?)
			connection.websocket.onerror = function(evt) { 
				connection.websocket = null;
				connection.commandQueue = [];
				connection.inputBuffer = "";
				if (callbackFailure) { callbackFailure(); }
			};
		}
		
		// OmmConnection.close();
		connection.close = function() {
console.log("Closing ('" + connection.port + "')...");
			if (connection.websocket) {
				connection.websocket.close();
				connection.websocket = null;
			}
		}
		
		
		// OmmConnection.getIdentity();
		connection.getIdentity = function(callbackSuccess, callbackFailure) {		
			queueCommand(OmmCommand("\r\nID\r\n", "ID=", 6000, function(line)
			{
				var ret = {};

				// "ID=hardwareName,hardwareVersion,firmwareVersion,deviceId,sessionId"
				var parts = line.substring(line.indexOf('=') + 1).split(",");
				
				//ret.raw = line;
				ret.deviceType = parts[0];
				ret.deviceId = parts[3];
				ret.firmwareVersion = parts[2];
			
				if (callbackSuccess) { callbackSuccess(ret); }
				
				return true;
			}, 
			function() {
				if (callbackFailure) { callbackFailure(); }
			}));		
		}
		
		// OmmConnection.getCapabilities();
		connection.getCapabilities = function(callbackSuccess, callbackFailure) {		
			var callback = function(devParam) {
				var ret = null;
				var deviceType = "";
				
				if (devParam != null) {
					deviceType = devParam.deviceType;
				} else if (typeof connection.serial != 'undefined') {
					deviceType = connection.serial;
				}
				
				// OmmCapabilities				
				
				if (deviceType.lastIndexOf("CWA", 0) === 0) {
					ret = {};
					ret.name = "AX3";
					ret.format = "CWA";
					ret.configAccel = {};
					ret.configAccel.frequency = [25, 50, 100, 200, 400, 800, 1600, 3200];
					ret.configAccel.sensitivity = [2, 4, 8, 16];
					ret.wireless = false;
				} else if (deviceType.lastIndexOf("MMM", 0) === 0) {
					ret = {};
					ret.name = "MMM";
					ret.format = "OMX";
					ret.configAccel = {};
					ret.configAccel.frequency = [50, 100, 200, 400, 800];
					ret.configAccel.sensitivity = [2, 4, 8];
					//ret.configGyro = {};
					//ret.configGyro.frequency = [100, 200, 400, 800];
					//ret.configGyro.sensitivity = [250, 500, 2000];
					ret.configMag = {};
					ret.configMag.frequency = [1, 2, 5, 10, 20, 40, 80];
					ret.configMag.sensitivity = [0];
					ret.configAlt = {};
					ret.configAlt.frequency = [1];
					ret.configAlt.sensitivity = [0];
					ret.configAdc = {};
					ret.configAdc.frequency = [1];
					ret.configAdc.sensitivity = [0];
					ret.wireless = false;
				} else if (deviceType.lastIndexOf("MMP", 0) === 0) {
					ret = {};
					ret.name = "MMP";
					ret.format = "OMX";
					ret.configAccel = {};
					ret.configAccel.frequency = [50, 100, 200, 400, 800];
					ret.configAccel.sensitivity = [2, 4, 8];
					ret.configGyro = {};
					ret.configGyro.frequency = [100, 200, 400, 800];
					ret.configGyro.sensitivity = [250, 500, 2000];
					ret.configMag = {};
					ret.configMag.frequency = [1, 2, 5, 10, 20, 40, 80];
					ret.configMag.sensitivity = [0];
					ret.configAlt = {};
					ret.configAlt.frequency = [1];
					ret.configAlt.sensitivity = [0];
					ret.configAdc = {};
					ret.configAdc.frequency = [1];
					ret.configAdc.sensitivity = [0];
					ret.wireless = false;
				} else if (deviceType.lastIndexOf("MMM", 0) === 0) {
					ret = {};
					ret.name = "MMM";
					ret.format = "OMX";
					ret.configAccel = {};
					ret.configAccel.frequency = [50, 100, 200, 400, 800];
					ret.configAccel.sensitivity = [2, 4, 8];
					ret.configGyro = {};
					ret.configGyro.frequency = [100, 200, 400, 800];
					ret.configGyro.sensitivity = [250, 500, 2000];
					ret.configMag = {};
					ret.configMag.frequency = [1, 2, 5, 10, 20, 40, 80];
					ret.configMag.sensitivity = [0];
					ret.configAlt = {};
					ret.configAlt.frequency = [1];
					ret.configAlt.sensitivity = [0];
					ret.configAdc = {};
					ret.configAdc.frequency = [1];
					ret.configAdc.sensitivity = [0];
					ret.wireless = true;
				}

				callbackSuccess(ret);
			}
			
			// Call getIdentity() for some connections
			if (typeof connection.serial == 'undefined')
			{
				connection.getIdentity(callback, callbackFailure);
			}
			else
			{
				callback(null);
			}
		}
		
		// OmmConnection.getTime();
		connection.getTime = function(callbackSuccess, callbackFailure) {		
			queueCommand(OmmCommand("\r\nTIME\r\n", "$TIME=", 6000, function(line)
			{
				var value = line.substring(line.indexOf('=') + 1);
				
				
				// "$TIME=YYYY-MM-DD,hh:mm:ss"
				var dateString = line.substring(6);
								
				var ret = parseDateTime(dateString);
			
				if (callbackSuccess) { callbackSuccess(ret); }
				
				return true;
			}, 
			function() {
				if (callbackFailure) { callbackFailure(); }
			}));		
		}
		
		// OmmConnection.getBattery();
		connection.getBattery = function(callbackSuccess, callbackFailure) {		
			queueCommand(OmmCommand("\r\nSAMPLE 1\r\n", "$BATT=", 6000, function(line)
			{
				var ret = {};

				// "$BATT=718,4207,mV,98,1"
				var parts = line.substring(line.indexOf('=') + 1).split(",");
				
				//ret.raw = line;
				ret.voltage = parts[1] / 1000.0;
				ret.percent = parts[3];
				ret.charging = parts[4];
			
				if (callbackSuccess) { callbackSuccess(ret); }
				
				return true;
			}, 
			function() {
				if (callbackFailure) { callbackFailure(); }
			}));		
		}
		
		// OmmConnection.getSettingsRecording();
		connection.getSettingsRecording = function(callbackSuccess, callbackFailure) {
			var ret = {};
			queueCommand(OmmCommand("\r\nSESSION\r\nHIBERNATE\r\nSTOP\r\n", ["SESSION=", "HIBERNATE=", "STOP="], 6000, function(line)
			{
				var value = line.substring(line.indexOf('=') + 1);

				if (line.indexOf("SESSION") === 0) { ret.sessionId = parseInt(value, 10); }
				else if (line.indexOf("HIBERNATE") === 0) { ret.startTime = parseDateTime(value); }
				else if (line.indexOf("STOP") === 0) { ret.endTime = parseDateTime(value); }
			
				if (typeof ret.sessionId !== "undefined" && typeof ret.startTime !== "undefined"  && typeof ret.endTime !== "undefined") {
					if (callbackSuccess) { callbackSuccess(ret); }
					return true;
				}
				return false;	// more to come
			}, 
			function() {
				if (callbackFailure) { callbackFailure(); }
			}));		
		}

		// OmmConnection.getSettingsSensors();
		connection.getSettingsSensors = function(callbackSuccess, callbackFailure) {
			var ret = {};

			var command;
			if (typeof connection.serial != 'undefined' && connection.serial.lastIndexOf("CWA", 0) === 0) {
				command = "\r\nRATE\r\n";
			} else {
				command = "\r\nRATE A\r\nRATE G\r\nRATE M\r\nRATE P\r\nRATE T\r\n";
			}
			
			queueCommand(OmmCommand(command, "RATE=", 6000, function(line)
			{
				var parts = line.substring(line.indexOf('=') + 1).split(",");

				//console.log(JSON.stringify(parts));				

				if (parts.length >= 1 && parts[0].length > 0)
				{
					if (parts[0].substr(0,1) >= '0' && parts[0].substr(0,1) <= '9') 
					{ 
						// CWA-type rate code
						var value = parseInt(parts[0]);
						var rate = (3200 / (1 << (15-(value & 0x0f))));
						var range = (16 >> (value >> 6));

						//console.log("> Rate command: " + rate + " / " + range + "");				
						
						// Return structure
						ret.configAccel = { enabled: 1, frequency: rate, sensitivity: range }; 
						if (callbackSuccess) { callbackSuccess(ret); }
						return true;
					}
					else
					{
						if (parts[0] == "A") { ret.configAccel = { enabled: parseInt(parts[1]), frequency: parseInt(parts[2]), sensitivity: parseInt(parts[3]) }; }
						else if (parts[0] == "G") { ret.configGyro  = { enabled: parseInt(parts[1]), frequency: parseInt(parts[2]), sensitivity: parseInt(parts[3]) }; }
						else if (parts[0] == "M") { ret.configMag   = { enabled: parseInt(parts[1]), frequency: parseInt(parts[2]), sensitivity: parseInt(parts[3]) }; }
						else if (parts[0] == "P") { ret.configAlt   = { enabled: parseInt(parts[1]), frequency: parseInt(parts[2]), sensitivity: parseInt(parts[3]) }; }
						else if (parts[0] == "T") { ret.configAdc   = { enabled: parseInt(parts[1]), frequency: parseInt(parts[2]), sensitivity: parseInt(parts[3]) }; }
						
						// Are we there yet?
						if (typeof ret.configAccel !== "undefined" && typeof ret.configGyro !== "undefined" && typeof ret.configMag !== "undefined" && typeof ret.configAlt !== "undefined" && typeof ret.configAdc !== "undefined") {
							if (callbackSuccess) { callbackSuccess(ret); }
							return true;
						}
					}
				}
				
				return false;	// more to come
			}, 
			function() {
				if (callbackFailure) { callbackFailure(); }
			}));		
		}

		// OmmConnection.getSettingsMetadata();
		connection.getSettingsMetadata = function(callbackSuccess, callbackFailure) {
			var ret = [null, null, null, null, null, null];
			queueCommand(OmmCommand("\r\nANNOTATE00\r\nANNOTATE01\r\nANNOTATE02\r\nANNOTATE03\r\nANNOTATE04\r\nANNOTATE05\r\n", ["ANNOTATE00=", "ANNOTATE01=", "ANNOTATE02=", "ANNOTATE03=", "ANNOTATE04=", "ANNOTATE05="], 6000, function(line)
			{
				var value = line.substring(line.indexOf('=') + 1);
				var block = parseInt(line.substring(8, 10), 10);
				
//console.log("METADATA #" + block + "=" + value + " -- raw:" + line);
				
				if (block < ret.length) { ret[block] = value; }
				
				if (ret[0] != null && ret[1] != null && ret[2] != null && ret[3] != null && ret[4] != null && ret[5] != null) {
					var metadata = (ret[0] + ret[1] + ret[2] + ret[3] + ret[4] + ret[5]).trim();
					if (callbackSuccess) { callbackSuccess(metadata); }
					return true;
				}
				return false;	// more to come
			}, 
			function() {
				if (callbackFailure) { callbackFailure(); }
			}));		
		}

		
		// OmmConnection.getSettings();
		// Broken into steps so as to not overwhelm the device input buffer
		connection.getSettings = function(callbackSuccess, callbackFailure) {
			var ret = {};
			
			// Step 1. Recording
			function stepRecording() {
				connection.getSettingsRecording(function (val) {
					ret.sessionId = val.sessionId;
					ret.startTime = val.startTime;
					ret.endTime = val.endTime;
					stepSensors();
				}, function() {
					stepSensors();
				});
			}
			
			// Step 2. Sensors
			function stepSensors() {
				connection.getSettingsSensors(function (val) {
					if (val != null && typeof val.configAccel !== "undefined") ret.configAccel = val.configAccel;
					if (val != null && typeof val.configGyro  !== "undefined") ret.configGyro  = val.configGyro;
					if (val != null && typeof val.configMag   !== "undefined") ret.configMag   = val.configMag;
					if (val != null && typeof val.configAlt   !== "undefined") ret.configAlt   = val.configAlt; 
					if (val != null && typeof val.configAdc   !== "undefined") ret.configAdc   = val.configAdc;
					stepMetadata();
				}, function() {
					stepMetadata();
				});
			}
			
			// Step 3. Metadata
			function stepMetadata() {
				connection.getSettingsMetadata(function (val) {
					ret.metadata = val;
					stepDone();
				}, function() {
					stepDone();
				});
			}
			
			// Step 4. Done
			function stepDone() {
				callbackSuccess(ret);
			}
			
			// Start it off...
			stepRecording();
		}

		
		// OmmConnection.setSettingsRecording();
		connection.setSettingsRecording = function(settings, callbackSuccess, callbackFailure) {
			var sessionId = (typeof settings.sessionId !== "undefined") ? settings.sessionId : 0;
			var startTime = packDateTime((typeof settings.startTime !== "undefined") ? settings.startTime : packDateTime(-1));
			var endTime   = packDateTime((typeof settings.endTime   !== "undefined") ? settings.endTime   : packDateTime(0));
			
			var command = "\r\nSESSION " + sessionId + "\r\nHIBERNATE " + startTime + "\r\nSTOP " + endTime + "\r\n";

			var count = 0;
			queueCommand(OmmCommand(command, ["SESSION=", "HIBERNATE=", "STOP="], 6000, function(line)
			{
				count++;
				if (count >= 3)
				{
					if (callbackSuccess) { callbackSuccess(); }
					return true;
				}
				return false;	// more to come
			}, 
			function() {
				if (callbackFailure) { callbackFailure(); }
			}));		
		}		

		// OmmConnection.setSettingsSensors();
		connection.setSettingsSensors = function(settings, callbackSuccess, callbackFailure) {
			var sessionId = (typeof settings.sessionId !== "undefined") ? settings.sessionId : 0;
			var startTime = packDateTime((typeof settings.startTime !== "undefined") ? settings.startTime : packDateTime(-1));
			var endTime   = packDateTime((typeof settings.endTime   !== "undefined") ? settings.endTime   : packDateTime(0));
			
			// Add any missing values
			if (typeof settings.configAccel             == "undefined") { settings.configAccel             = {}; } 
			if (typeof settings.configAccel.enabled     == "undefined") { settings.configAccel.enabled     = 1; } 
			if (typeof settings.configAccel.frequency   == "undefined") { settings.configAccel.frequency   = 100; } 
			if (typeof settings.configAccel.sensitivity == "undefined") { settings.configAccel.sensitivity = 8; } 
			if (typeof settings.configGyro              == "undefined") { settings.configGyro              = {}; } 
			if (typeof settings.configGyro.enabled      == "undefined") { settings.configGyro.enabled      = 1; } 
			if (typeof settings.configGyro.frequency    == "undefined") { settings.configGyro.frequency    = 100; } 
			if (typeof settings.configGyro.sensitivity  == "undefined") { settings.configGyro.sensitivity  = 2000; } 
			if (typeof settings.configMag               == "undefined") { settings.configMag               = {}; } 
			if (typeof settings.configMag.enabled       == "undefined") { settings.configMag.enabled       = 1; } 
			if (typeof settings.configMag.frequency     == "undefined") { settings.configMag.frequency     = 10; } 
			if (typeof settings.configMag.sensitivity   == "undefined") { settings.configMag.sensitivity   = 0; } 
			if (typeof settings.configAlt               == "undefined") { settings.configAlt               = {}; } 
			if (typeof settings.configAlt.enabled       == "undefined") { settings.configAlt.enabled       = 1; } 
			if (typeof settings.configAlt.frequency     == "undefined") { settings.configAlt.frequency     = 1; } 
			if (typeof settings.configAlt.sensitivity   == "undefined") { settings.configAlt.sensitivity   = 0; } 
			if (typeof settings.configAdc               == "undefined") { settings.configAdc               = {}; } 
			if (typeof settings.configAdc.enabled       == "undefined") { settings.configAdc.enabled       = 1; } 
			if (typeof settings.configAdc.frequency     == "undefined") { settings.configAdc.frequency     = 1; } 
			if (typeof settings.configAdc.sensitivity   == "undefined") { settings.configAdc.sensitivity   = 0; } 

			// Construct command
			var command = "\r\n";
			
			if (typeof connection.serial != 'undefined' && connection.serial.lastIndexOf("CWA", 0) === 0) {
				var value = 0;
				
				// CWA-type rate code frequency
				switch (settings.configAccel.frequency)
				{
					case 3200: value |= 0x0f; break;
					case 1600: value |= 0x0e; break;
					case  800: value |= 0x0d; break;
					case  400: value |= 0x0c; break;
					case  200: value |= 0x0b; break;
					case  100: value |= 0x0a; break;
					case   50: value |= 0x09; break;
					case   25: value |= 0x08; break;
					case   12: value |= 0x07; break;
					case    6: value |= 0x06; break;
					default: callbackFailure("Invalid accelerometer frequency."); return;
				}
				
				// CWA-type rate code sensitivity
				switch (settings.configAccel.sensitivity)
				{
					case 16:   value |= 0x00; break;
					case  8:   value |= 0x40; break;
					case  4:   value |= 0x80; break;
					case  2:   value |= 0xC0; break;
					default: callbackFailure("Invalid accelerometer sensitivity."); return;
				}
				
				command = command + "RATE " + value + "\r\n"; 
			} else {
				command = command + "RATE A " + settings.configAccel.enabled + " " + settings.configAccel.frequency + " " + settings.configAccel.sensitivity + "\r\n"; 
				command = command + "RATE G " + settings.configGyro.enabled  + " " + settings.configGyro.frequency  + " " + settings.configGyro.sensitivity  + "\r\n"; 
				command = command + "RATE M " + settings.configMag.enabled   + " " + settings.configMag.frequency   + " " + settings.configMag.sensitivity   + "\r\n"; 
				command = command + "RATE P " + settings.configAlt.enabled   + " " + settings.configAlt.frequency   + " " + settings.configAlt.sensitivity   + "\r\n"; 
				command = command + "RATE T " + settings.configAdc.enabled   + " " + settings.configAdc.frequency   + " " + settings.configAdc.sensitivity   + "\r\n"; 
			}
			

			var count = 0;
			queueCommand(OmmCommand(command, "RATE=", 6000, function(line)
			{
				count++;
				if (count >= 5)
				{
					if (callbackSuccess) { callbackSuccess(connection); }
					return true;
				}
				return false;	// more to come
			}, 
			function() {
				if (callbackFailure) { callbackFailure(); }
			}));		
		}		


		// OmmConnection.setSettingsMetadata();
		connection.setSettingsMetadata = function(settings, callbackSuccess, callbackFailure) {
			var count = 0;
			var text = (typeof settings.metadata !== "undefined") ? settings.metadata : "";
			command = "\r\n";
			for (i = 0; i < 6; i++)
			{
				var strip = "";
				var start = i * 32;
				var end = (i + 1) * 32;
				if (start < text.length)
				{
					if (end > text.length) { end = text.length; }
					{
						strip = text.substring(start, end);
					}
				}
				// Lower-case so we can distinguish an echoed command from the response (usually use ':' or ' ' to separate, but ANNOTATE on the CWA needs a '=')
				command = command + "annotate0" + i + "=" + strip.trim() + "\r\n";
			}

//		console.log("METADATA: " + command);
			
			queueCommand(OmmCommand(command, ["ANNOTATE00=", "ANNOTATE01=", "ANNOTATE02=", "ANNOTATE03=", "ANNOTATE04=", "ANNOTATE05="], 8000, function(line)
			{
				var value = line.substring(line.indexOf('=') + 1);
				var block = parseInt(line.substring(8, 10), 10);
				
//console.log("METADATA #" + block + "=" + value + " -- raw:" + line);
				
				//if (block < ret.length) { ret[block] = value; }
				
				count++;
				if (count >= 6) {
					if (callbackSuccess) { callbackSuccess(); }
					return true;
				}
				
				return false;	// more to come
			}, 
			function() {
				if (callbackFailure) { callbackFailure(); }
			}));		
		}

		// OmmConnection.setSettingsCommit();
		connection.setSettingsCommit = function(settings, callbackSuccess, callbackFailure) {		
			queueCommand(OmmCommand("\r\nCOMMIT\r\n", "COMMIT", 8000, function(line)
			{
				if (line == "COMMIT")
				{
					if (callbackSuccess) { callbackSuccess(); }
					return true;
				}
				else
				{
					return false;
				}
			}, 
			function() {
				if (callbackFailure) { callbackFailure(); }
			}));		
		}

		// Broken into steps so as to not overwhelm the device input buffer
		connection.setSettings = function(settings, callbackSuccess, callbackFailure) {
			
			// Step 1. Recording
			function stepRecording() {
				connection.setSettingsRecording(settings, function (val) {
					stepSensors();
				}, function() {
					stepSensors();
				});
			}
			
			// Step 2. Sensors
			function stepSensors() {
				connection.setSettingsSensors(settings, function (val) {
					stepMetadata();
				}, function() {
					stepMetadata();
				});
			}
			
			// Step 3. Metadata
			function stepMetadata() {
				connection.setSettingsMetadata(settings, function (val) {
					stepCommit();
				}, function() {
					stepCommit();
				});
			}
			
			// Step 4. Commit
			function stepCommit() {
				connection.setSettingsCommit(settings, function (val) {
					stepDone();
				}, function() {
					stepDone();
				});
			}
			
			// Step 5. Done
			function stepDone() {
				callbackSuccess();
			}
			
			// Start it off...
			stepRecording(settings);
		}


		// OmmConnection.getMemory();
		connection.getMemory = function(callbackSuccess, callbackFailure) {	
		
			// Must be on a connection with a path
			if (typeof connection.path === 'undefined') { callbackFailure(); return; }
			
			// AJAX request
			var xmlhttp;
			xmlhttp = (window.XMLHttpRequest) ? (new XMLHttpRequest()) : (new ActiveXObject("Microsoft.XMLHTTP"));
			xmlhttp.onreadystatechange = function() {
				if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
				{
					var response = (JSON && JSON.parse) ? JSON.parse(xmlhttp.responseText) : eval('(' + xmlhttp.responseText + ')');
					memory = {};
					// Read relevant parts
					if (typeof response.free     !== 'undefined') { memory.free     = response.free;     }
					if (typeof response.capacity !== 'undefined') { memory.capacity = response.capacity; }
					if (typeof response.used     !== 'undefined') { memory.used     = response.used;     }
					if (callbackSuccess) { callbackSuccess(memory); }
				}
				else if (xmlhttp.readyState == 4)
				{
					if (callbackFailure) { callbackFailure(); }
				}
			}
			xmlhttp.open("GET", "" + manager.getDomain("http") + "/memory?path=" + encodeURIComponent(connection.path), true);
			xmlhttp.send();	
		}
		
		
		// OmmConnection.getFiles();
		connection.getFiles = function(callbackSuccess, callbackFailure) {	
		
			// Must be on a connection with a path
			if (typeof connection.path === 'undefined') { callbackFailure(); return; }
			
			// AJAX request
			var xmlhttp;
			xmlhttp = (window.XMLHttpRequest) ? (new XMLHttpRequest()) : (new ActiveXObject("Microsoft.XMLHTTP"));
			xmlhttp.onreadystatechange = function() {
				if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
				{
					var response = (JSON && JSON.parse) ? JSON.parse(xmlhttp.responseText) : eval('(' + xmlhttp.responseText + ')');
					
					var files = [];
					for (var i = 0; i < response.files.length; i++)
					{
						// Make OmmConnection object
						var fileData = response.files[i];
						var file = {};
						
						// Read relevant parts
						if (typeof fileData.name             !== 'undefined') { file.name             = fileData.name            ; }
						if (typeof fileData.filename         !== 'undefined') { file.filename         = fileData.filename        ; }
						if (typeof fileData.size             !== 'undefined') { file.size             = fileData.size            ; }
						if (typeof fileData.lastModifiedDate !== 'undefined') { file.lastModifiedDate = new Date(fileData.lastModifiedDate * 1000); }
						if (typeof fileData.createdDate      !== 'undefined') { file.createdDate      = new Date(fileData.createdDate * 1000); }
						if (typeof fileData.archive          !== 'undefined') { file.archive          = (fileData.archive != 0); }
						
						files.push(file);
					}
					if (callbackSuccess) { callbackSuccess(files); }
				}
				else if (xmlhttp.readyState == 4)
				{
					if (callbackFailure) { callbackFailure(); }
				}
			}
			xmlhttp.open("GET", "" + manager.getDomain("http") + "/listing?path=" + encodeURIComponent(connection.path), true);
			xmlhttp.send();	
		}		
	    
		// OmmConnection.getMetadataAdvanced(fileName:String, advancedOptions:object);  // OmmMetadata { deviceInformation:OmmDeviceInformation, settings:OmmSettings, fileInformation:OmmFile }
		connection.getMetadataAdvanced = function(filename, advancedOptions, callbackSuccess, callbackFailure) {
			return getMetadataAdvanced(filename, connection.path, advancedOptions, callbackSuccess, callbackFailure);
		}
		
		// OmmConnection.getMetadata(fileName:String);  // OmmMetadata { deviceInformation:OmmDeviceInformation, settings:OmmSettings, fileInformation:OmmFile }
		connection.getMetadata = function(filename, callbackSuccess, callbackFailure) {
			return connection.getMetadataAdvanced(filename, null, callbackSuccess, callbackFailure);
		};
		
		// OmmConnection.remove(fileName:String);
		connection.remove = function(filename, callbackSuccess, callbackFailure) {
		
			// AJAX request
			var xmlhttp;
			xmlhttp = (window.XMLHttpRequest) ? (new XMLHttpRequest()) : (new ActiveXObject("Microsoft.XMLHTTP"));
			xmlhttp.onreadystatechange = function() {
				if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
				{
					var response = (JSON && JSON.parse) ? JSON.parse(xmlhttp.responseText) : eval('(' + xmlhttp.responseText + ')');
					
					if (callbackSuccess) { callbackSuccess(); }
				}
				else if (xmlhttp.readyState == 4)
				{
					if (callbackFailure) { callbackFailure(); }
				}
			}
			xmlhttp.open("POST", "" + manager.getDomain("http") + "/remove?path=" + encodeURIComponent(connection.path) + "&file=" + encodeURIComponent(filename), true);
			xmlhttp.send();				
		};
		
		// OmmConnection.preview(fileName:String);
		connection.preview = function(filename, previewParameters) {
			return previewImageUrl(filename, connection.path, previewParameters);
		};

		// OmmConnection.updateFirmware(firmwareName:String);
		connection.updateFirmware = function(firmwareName, callbackSuccess, callbackFailure) {
		
			// AJAX request
			var xmlhttp;
			xmlhttp = (window.XMLHttpRequest) ? (new XMLHttpRequest()) : (new ActiveXObject("Microsoft.XMLHTTP"));
			xmlhttp.onreadystatechange = function() {
				if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
				{
					var response = (JSON && JSON.parse) ? JSON.parse(xmlhttp.responseText) : eval('(' + xmlhttp.responseText + ')');
					
					if (callbackSuccess) { callbackSuccess(); }
				}
				else if (xmlhttp.readyState == 4)
				{
					if (callbackFailure) { callbackFailure(); }
				}
			}
			xmlhttp.open("POST", "" + manager.getDomain("http") + "/firmware?port=" + encodeURIComponent(connection.port) + "&path=" + encodeURIComponent(connection.path) + "&file=" + encodeURIComponent(firmwareName), true);
			xmlhttp.send();				
		};
		
		// OmmConnection.format();
		connection.format = function(callbackSuccess, callbackFailure) {		
			queueCommand(OmmCommand("\r\nFORMAT Q\r\n", "FORMAT: Complete.", 10000, function(line)
			{
				if (callbackSuccess) { callbackSuccess(); }
				return true;
			}, 
			function() {
				if (callbackFailure) { callbackFailure(); }
			}));		
		}

		// OmmConnection.setLed();
		connection.setLed = function(led, callbackSuccess, callbackFailure) {		
			queueCommand(OmmCommand("\r\nLED " + led + "\r\n", "LED=", 6000, function(line)
			{
				if (callbackSuccess) { callbackSuccess(); }
				return true;
			}, 
			function() {
				if (callbackFailure) { callbackFailure(); }
			}));		
		}
		
		// OmmConnection.setTime();
		connection.setTime = function(newTime, callbackSuccess, callbackFailure) {		
		
			newTime = ((typeof newTime === 'undefined') ? null : newTime);	
			var timestr = packDateTime(newTime);
						
			queueCommand(OmmCommand("\r\nTIME " + timestr + "\r\n", "$TIME=", 6000, function(line)
			{
				if (callbackSuccess) { callbackSuccess(); }
				return true;
			}, 
			function() {
				if (callbackFailure) { callbackFailure(); }
			}));		
		}
		
		// OmmConnection.annotation();
		connection.annotation = function(label, callbackSuccess, callbackFailure) {		
			queueCommand(OmmCommand("\r\ANNOTATION" + (label == null ? "" : (" " + label)) + "\r\n", "ANNOTATION", 8000, function(line)
			{
				if (callbackSuccess) { callbackSuccess(ret); }
				return true;
			}, 
			function() {
				if (callbackFailure) { callbackFailure(); }
			}));		
		}
		
		// OmmConnection.stream();
		connection.stream = function(status, callbackSuccess, callbackFailure) {		
			queueCommand(OmmCommand("\r\STREAM " + status + "\r\n", "STREAM", 6000, function(line)
			{
				if (callbackSuccess) { callbackSuccess(ret); }
				return true;
			}, 
			function() {
				if (callbackFailure) { callbackFailure(); }
			}));		
		}
		
		// OmmConnection.recording();
		connection.recording = function(status, callbackSuccess, callbackFailure) {		
			queueCommand(OmmCommand("\r\RECORDING " + status + "\r\n", "RECORDING", 6000, function(line)
			{
				if (callbackSuccess) { callbackSuccess(ret); }
				return true;
			}, 
			function() {
				if (callbackFailure) { callbackFailure(); }
			}));		
		}
		
		// OmmConnection.reset();
		connection.reset = function(callbackSuccess, callbackFailure) {		
			queueCommand(OmmCommand("\r\nRESET\r\n", "OK", 6000, function(line)
			{
				if (callbackSuccess) { callbackSuccess(); }
				return true;
			}, 
			function() {
				if (callbackFailure) { callbackFailure(); }
			}));		
		}
		
		// OmmConnection.customCommand();
		connection.customCommand = function(command, expectedPrefix, timeout, callbackSuccess, callbackFailure) {
			queueCommand(OmmCommand("\r\n" + command + "\r\n", expectedPrefix, timeout, callbackSuccess, callbackFailure));
		}
		
		return connection;
	}
	
	
	
	// OmmProcess
	var OmmProcess = function(type, processInfo) {
		var process = {};
		
		// Copy fields
		process.name = processInfo.name;
		
		// Process information
		process.websocket = null;
		
		// OmmProcess.open();
		process.open = function(callbackSuccess, callbackFailure, callbackReceived, callbackClosed) {
			
			// Close if currently open
			if (process.websocket) {
				process.close();
			}
			
			var wsUri = "" + manager.getDomain("ws") + "/" + type + "?name=" + process.name;
			
			if (typeof processInfo.file != 'undefined')
			{
				wsUri = wsUri + "&file=" + processInfo.file + "";
			}
			
console.log("Creating WebSocket object for process '" + process.name + "': " + wsUri);

			process.websocket = new WebSocket(wsUri);
			
			//process.websocket.binaryType = "blob";
			process.websocket.binaryType = "arraybuffer";			
			
			process.websocket.onopen = function(evt) { 
				if (callbackSuccess) { callbackSuccess(); } 
			};
			
			process.websocket.onclose = function(evt) {
				if (callbackClosed) { callbackClosed(); }
				process.websocket = null;
			};
			
			// Read incoming port data
			process.websocket.onmessage = function(evt) {
				var data = evt.data
				
				// Treat binary data as 8-bit ASCII
				if (data instanceof ArrayBuffer) {
					var bytearray = new Uint8Array(data);
					var i, len = bytearray.length;
					var result = '';
					for (i = 0; i < len; i++) {
					    result += String.fromCharCode(bytearray[i]);
					}
					data = result;
				} 
				
				if (callbackReceived) { 
					callbackReceived(data); 
				} else {
console.log("(PROCESS) " + data);
				}
			};
			
			// Error calls failure callback (replace after open?)
			process.websocket.onerror = function(evt) { 
				process.websocket = null;
				if (callbackFailure) { callbackFailure(); }
			};
		}
		
		process.write = function(output)
		{
			if (process.websocket == null) { return false; }
			process.websocket.send(output);
			return true;
		}
		
		// OmmProcess.close();
		process.close = function() {
console.log("Closing ('" + process.port + "')...");
			if (process.websocket) {
				process.websocket.close();
				process.websocket = null;
			}
		}
		
		return process;
	}

	manager.startProcess = function(processInfo) {
		var newProcess = OmmProcess("process", processInfo);
		return newProcess;
	}
	
	manager.startBootload = function(bootloadInfo) {
		var newBootload = OmmProcess("firmware", bootloadInfo);
		return newBootload;
	}
	
	
	manager.getDomain = function(protocol) {
		var domain = manager.domain;
		// Note: This only works when domain is either "http:" or "https:"
		if (domain.lastIndexOf("http", 0) === 0) { domain = domain.substring(4); }
		return protocol + domain;
	}
	
	manager.getConnectionUrl = function() {
		// TODO: Get domain from loader after this script is loaded.
		return "" + manager.getDomain("ws") + "/serial?port=";		// encodeURIComponent()
	}

	// Private list of connections
	manager.connections = [];
	
	// OmmManager.getConnections()
	manager.getConnections = function(callbackSuccess, callbackFailure) {	
		// AJAX request
		var xmlhttp;
		xmlhttp = (window.XMLHttpRequest) ? (new XMLHttpRequest()) : (new ActiveXObject("Microsoft.XMLHTTP"));
		xmlhttp.onreadystatechange = function() {
			if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
			{
				var response = (JSON && JSON.parse) ? JSON.parse(xmlhttp.responseText) : eval('(' + xmlhttp.responseText + ')');
				
				// We'll check the 'ports' part of the response
				if (response.ports)
				{
					// Assemble a list of connections
					var newConnections = [];
					for (var i = 0; i < response.ports.length; i++)
					{
						// OmmConnection object
						var newConnection = null;

						// Keep any existing connection object
						for (var j = 0; j < manager.connections.length; j++)
						{
							// If it's the same port identifier...
							if (response.ports[i].port == manager.connections[j].port)
							{
								// If the other details match
								if (response.ports[i].type == manager.connections[j].type)
								{
									newConnection = manager.connections[j];
								}
							}
						}
						
						// If we don't have an existing connection object, create one
						if (newConnection == null)
						{
							newConnection = OmmConnection(response.ports[i]);
						}
						
						// Add the connection
						newConnections.push(newConnection);
					}
					
					// Set our list of connections
					manager.connections = newConnections;
					if (callbackSuccess) { callbackSuccess(manager.connections); }
				}
				else
				{
					if (callbackFailure) { callbackFailure('no port field in returned object'); }
				}
			}
			else if (xmlhttp.readyState == 4)
			{
				if (callbackFailure) { callbackFailure('response status code not success'); }
			}
		}
		xmlhttp.open("GET", "" + manager.getDomain("http") + "/ports", true);	// encodeURIComponent()
		xmlhttp.send();	
	}
	
	
	// OmmConnection
	var OmmStore = function() {
		var store = {};
	
	
		// OmmStore.getFiles();
		store.getFiles = function(callbackSuccess, callbackFailure) {
		
			// AJAX request
			var xmlhttp;
			xmlhttp = (window.XMLHttpRequest) ? (new XMLHttpRequest()) : (new ActiveXObject("Microsoft.XMLHTTP"));
			xmlhttp.onreadystatechange = function() {
				if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
				{
					var response = (JSON && JSON.parse) ? JSON.parse(xmlhttp.responseText) : eval('(' + xmlhttp.responseText + ')');
					
					var files = [];
					for (var i = 0; i < response.files.length; i++)
					{
						// Make OmmFile object
						var fileData = response.files[i];
						var file = {};
						
						// Read relevant parts, parsing date/times
						if (typeof fileData.name             !== 'undefined') { file.name             = fileData.name            ; }
						if (typeof fileData.filename         !== 'undefined') { file.filename         = fileData.filename        ; }
						if (typeof fileData.size             !== 'undefined') { file.size             = fileData.size            ; }
						if (typeof fileData.lastModifiedDate !== 'undefined') { file.lastModifiedDate = new Date(fileData.lastModifiedDate * 1000); }
						if (typeof fileData.createdDate      !== 'undefined') { file.createdDate      = new Date(fileData.createdDate * 1000); }
						if (typeof fileData.archive          !== 'undefined') { file.archive          = (fileData.archive != 0); }
						
						files.push(file);
					}
					if (callbackSuccess) { callbackSuccess(files); }
				}
				else if (xmlhttp.readyState == 4)
				{
					if (callbackFailure) { callbackFailure(); }
				}
			}
			xmlhttp.open("GET", "" + manager.getDomain("http") + "/listing", true);	// encodeURIComponent()
			xmlhttp.send();				
		};

		
		// OmmStore.getTransfers();
		store.getTransfers = function(callbackSuccess, callbackFailure) {
		
			// AJAX request
			var xmlhttp;
			xmlhttp = (window.XMLHttpRequest) ? (new XMLHttpRequest()) : (new ActiveXObject("Microsoft.XMLHTTP"));
			xmlhttp.onreadystatechange = function() {
				if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
				{
					var response = (JSON && JSON.parse) ? JSON.parse(xmlhttp.responseText) : eval('(' + xmlhttp.responseText + ')');
					
					if (callbackSuccess) { callbackSuccess(response); }
				}
				else if (xmlhttp.readyState == 4)
				{
					if (callbackFailure) { callbackFailure(); }
				}
			}
			xmlhttp.open("GET", "" + manager.getDomain("http") + "/transfers", true);	// encodeURIComponent()
			xmlhttp.send();				
		};

		
		// OmmStore.remove(storeFileName:String);
		store.remove = function(filename, callbackSuccess, callbackFailure) {
		
			// AJAX request
			var xmlhttp;
			xmlhttp = (window.XMLHttpRequest) ? (new XMLHttpRequest()) : (new ActiveXObject("Microsoft.XMLHTTP"));
			xmlhttp.onreadystatechange = function() {
				if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
				{
					var response = (JSON && JSON.parse) ? JSON.parse(xmlhttp.responseText) : eval('(' + xmlhttp.responseText + ')');
					
					if (callbackSuccess) { callbackSuccess(); }
				}
				else if (xmlhttp.readyState == 4)
				{
					if (callbackFailure) { callbackFailure(); }
				}
			}
			xmlhttp.open("POST", "" + manager.getDomain("http") + "/remove?file=" + encodeURIComponent(filename), true);
			xmlhttp.send();				
		};

		
		// OmmStore.preview(storeFileName:String,previewParameters:object);
		store.preview = function(filename, previewParameters) {
			return previewImageUrl(filename, null, previewParameters);
		};
		
		
		// OmmStore.getMetadata(fileName:String);  // OmmMetadata { deviceInformation:OmmDeviceInformation, settings:OmmSettings, fileInformation:OmmFile }
		store.getMetadata = function(filename, callbackSuccess, callbackFailure) {
			return getMetadataAdvanced(filename, null, null, callbackSuccess, callbackFailure);
		}
		
		// OmmStore.getMetadataAdvanced(fileName:String, advancedOptions:object);  // OmmMetadata { deviceInformation:OmmDeviceInformation, settings:OmmSettings, fileInformation:OmmFile }
		store.getMetadataAdvanced = function(filename, advancedOptions, callbackSuccess, callbackFailure) {
			return getMetadataAdvanced(filename, null, advancedOptions, callbackSuccess, callbackFailure);
		};

		
		// OmmStore.download(storeFilename:String, downloadParameters:Object, callbackSuccess:function, callbackFailure:function, callbackProgress:function);
		store.download = function(storeFilename, downloadParameters, callbackSuccess, callbackFailure, callbackProgress) {
		
			if (typeof storeFilename == 'undefined' || storeFilename == null || storeFilename == "") {
				if (callbackFailure) { callbackFailure('No store filename specified.'); }
				return;
			}
			if (typeof downloadParameters == 'undefined' || downloadParameters == null) {
				if (callbackFailure) { callbackFailure('No download parameters specified.'); }
				return;
			}
			
			// Bools
			var cancel = (typeof downloadParameters.cancel != 'undefined' && downloadParameters.cancel);
			var resume = (typeof downloadParameters.resume != 'undefined' && downloadParameters.resume);
			
			var address;
			if (cancel)
			{
				address = "" + manager.getDomain("http") + "/download?storeFile=" + encodeURIComponent(storeFilename) + "&cancel=1";
			}
			else
			{
				// Check a source exists
				if (typeof downloadParameters.sourceFilename == 'undefined' || downloadParameters.sourceFilename == null || downloadParameters.sourceFilename == "") {
					if (typeof downloadParameters.sourceUrl == 'undefined' || downloadParameters.sourceUrl == null || downloadParameters.sourceUrl == "") {
						if (callbackFailure) { callbackFailure('No source specified.'); }
						return;
					}
				}
				if (typeof downloadParameters.connection == 'undefined' || downloadParameters.connection == null) {
					if (callbackFailure) { callbackFailure('No connection specified.'); }
					return;
				}
				//if (typeof downloadParameters.connection.path == 'undefined' || downloadParameters.connection.path == null || downloadParameters.connection.path == "") {
				//	if (callbackFailure) { callbackFailure('Connection has no path.'); }
				//	return;
				//}
				//path = connection.path;
				address = "" + manager.getDomain("http") + "/download?storeFile=" + encodeURIComponent(storeFilename);
				
				if (typeof downloadParameters.sourceFilename != 'undefined' && downloadParameters.sourceFilename != null && downloadParameters.sourceFilename != "") {
					address = address + "&sourceFile=" + encodeURIComponent(downloadParameters.sourceFilename);
				}
				if (typeof downloadParameters.sourceUrl != 'undefined' && downloadParameters.sourceUrl != null && downloadParameters.sourceUrl != "") {
					address = address + "&sourceUrl=" + encodeURIComponent(downloadParameters.sourceUrl);
				}
				 
				if (resume) { address = address + "&resume=1"; }
			}
			
			
			// AJAX request
			var xmlhttp;
			xmlhttp = (window.XMLHttpRequest) ? (new XMLHttpRequest()) : (new ActiveXObject("Microsoft.XMLHTTP"));
			xmlhttp.onreadystatechange = function() {
				if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
				{
					var response = (JSON && JSON.parse) ? JSON.parse(xmlhttp.responseText) : eval('(' + xmlhttp.responseText + ')');
					
					// Pass response through
					if (callbackSuccess) { callbackSuccess(response); }
				}
				else if (xmlhttp.readyState == 4)
				{
					if (callbackFailure) { callbackFailure(); }
				}
			}
			
			xmlhttp.open("POST", address, true);
			xmlhttp.send();				
		};

		
		// OmmStore.upload(storeFilename:String, uploadParameters:Object, callbackSuccess:function, callbackFailure:function, callbackProgress:function);
		store.upload = function(storeFilename, uploadParameters, callbackSuccess, callbackFailure, callbackProgress) {
		
			if (typeof storeFilename == 'undefined' || storeFilename == null || storeFilename == "") {
				if (callbackFailure) { callbackFailure('No store filename specified.'); }
				return;
			}
			if (typeof uploadParameters == 'undefined' || uploadParameters == null) {
				if (callbackFailure) { callbackFailure('No upload parameters specified.'); }
				return;
			}
			
			// Bools
			var cancel = (typeof uploadParameters.cancel != 'undefined' && uploadParameters.cancel);
			var address;
			
			if (cancel)
			{
				address = "" + manager.getDomain("http") + "/upload?storeFile=" + encodeURIComponent(storeFilename) + "&cancel=1";
			}
			else
			{
				if (typeof uploadParameters.url == 'undefined' || uploadParameters.url == null || uploadParameters.url == "") {
					if (callbackFailure) { callbackFailure('No URL specified (uploadParameters.url).'); }
					return;
				}
				var url = uploadParameters.url;
				
				address = "" + manager.getDomain("http") + "/upload?storeFile=" + encodeURIComponent(storeFilename) + "&destUrl=" + encodeURIComponent(uploadParameters.url);
				
				if (typeof uploadParameters.uploadOffset != 'undefined') {
					address = address + "&uploadOffset=" + encodeURIComponent(uploadParameters.uploadOffset);
				}
				
				if (typeof uploadParameters.uploadLimit != 'undefined') {
					address = address + "&uploadLimit=" + encodeURIComponent(uploadParameters.uploadLimit);
				}

				if (typeof uploadParameters.method != 'undefined') {
					address = address + "&method=" + encodeURIComponent(uploadParameters.method);
				}
			}
				
			// AJAX request
			var xmlhttp;
			xmlhttp = (window.XMLHttpRequest) ? (new XMLHttpRequest()) : (new ActiveXObject("Microsoft.XMLHTTP"));
			xmlhttp.onreadystatechange = function() {
				if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
				{
					var response = (JSON && JSON.parse) ? JSON.parse(xmlhttp.responseText) : eval('(' + xmlhttp.responseText + ')');
					
					// Pass response through
					if (callbackSuccess) { callbackSuccess(response); }
				}
				else if (xmlhttp.readyState == 4)
				{
					if (callbackFailure) { callbackFailure(); }
				}
			}
			xmlhttp.open("POST", address, true);
			xmlhttp.send();				
		};
		
		return store;
	}();
	
	// Private local
	manager.store = OmmStore;
	
	// OmmManager.getStore()
	manager.getStore = function() { 
		return manager.store;
	}
	
	// OmmManager.getFirmware()
	manager.getFirmware = function(callbackSuccess, callbackFailure) {
	
		// AJAX request
		var xmlhttp;
		xmlhttp = (window.XMLHttpRequest) ? (new XMLHttpRequest()) : (new ActiveXObject("Microsoft.XMLHTTP"));
		xmlhttp.onreadystatechange = function() {
			if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
			{
				var response = (JSON && JSON.parse) ? JSON.parse(xmlhttp.responseText) : eval('(' + xmlhttp.responseText + ')');
				
				var files = [];
				for (var i = 0; i < response.files.length; i++)
				{
					// Make OmmFile object
					var fileData = response.files[i];
					var file = {};
					
					// Read relevant parts, parsing date/times
					if (typeof fileData.name             !== 'undefined') { file.name             = fileData.name            ; }
					if (typeof fileData.filename         !== 'undefined') { file.filename         = fileData.filename        ; }
					if (typeof fileData.size             !== 'undefined') { file.size             = fileData.size            ; }
					if (typeof fileData.lastModifiedDate !== 'undefined') { file.lastModifiedDate = new Date(fileData.lastModifiedDate * 1000); }
					if (typeof fileData.createdDate      !== 'undefined') { file.createdDate      = new Date(fileData.createdDate * 1000); }
					if (typeof fileData.archive          !== 'undefined') { file.archive          = (fileData.archive != 0); }
					
					files.push(file);
				}
				if (callbackSuccess) { callbackSuccess(files); }
			}
			else if (xmlhttp.readyState == 4)
			{
				if (callbackFailure) { callbackFailure(); }
			}
		}
		xmlhttp.open("GET", "" + manager.getDomain("http") + "/firmware", true);	// encodeURIComponent()
		xmlhttp.send();				
	};
	
	// Reconnect state
	manager.websocket = null;
	manager.isConnected = false;
	manager.firstPacket = false;
	manager.reconnectInterval = 1;
	manager.middlewareVersion = null;
	
	// Reconnect
	manager.reconnect = function(successCallback) {
			
console.log("Update re-connect...");

		// Close if currently open
		if (manager.websocket != null) {
			manager.websocket.close();
		}
			
		var wsUri = "" + manager.getDomain("ws") + "/updates";		// encodeURIComponent()
		manager.websocket = null;
		manager.firstPacket = false;
	
		console.log("Creating WebSocket object for updates: " + wsUri);
//		try {
			manager.websocket = new WebSocket(wsUri);
//		} catch(err) { console.log("ERROR: Problem connecting websocket..."); }
			
		if (manager.websocket != null) {
			//manager.websocket.binaryType = "blob";
			manager.websocket.binaryType = "arraybuffer";			
				
			manager.websocket.onopen = function(evt) { 
				manager.isConnected = true;
				manager.reconnectInterval = 1;	// reset retry counter
				//if (manager.updatesResumedHandler != null) { manager.updatesResumedHandler(); }
				////if (callbackSuccess) { callbackSuccess(); } 
			};
				
			manager.websocket.onclose = function(evt) {
				manager.reconnectInterval = 2 * manager.reconnectInterval;
				if (manager.reconnectInterval > 4) { manager.reconnectInterval = 4; }
				var reconnectTimer = manager.reconnectInterval * 1000;
				
console.log("Update connection closed, re-open in " + (reconnectTimer / 1000) + "...");

				manager.websocket = null;
				if (manager.isConnected)
				{
					manager.isConnected = false;
					if (manager.firstPacket)
					{
						if (manager.updatesLostHandler != null) { manager.updatesLostHandler(); }
					}
				}
				manager.firstPacket = false;
				
// TODO:				setTimeout(function() { manager.reconnect(); }, reconnectTimer);
			};
				
			// Buffer incoming update data
			manager.websocket.onmessage = function(evt) {
				var rawData = evt.data;
				var update = (JSON && JSON.parse) ? JSON.parse(rawData) : eval('(' + rawData + ')');
				
				if (typeof update.version != "undefined") 
				{
					console.log("]]] update.version = " + update.version + "");
					manager.middlewareVersion = update.version;
				}
				
				if (typeof update.ping != "undefined") 
				{
					//console.log("]]] update.ping = " + update.ping + ", update.uptime = " + update.uptime + "");
				}

				if (!manager.firstPacket)
				{
					manager.firstPacket = true;
					manager.isConnected = true;
					manager.reconnectInterval = 1;	// reset retry counter
					if (successCallback != null)
					{
						successCallback();
					}
					if (manager.updatesResumedHandler != null) { manager.updatesResumedHandler(); }
				}
				
				if (typeof update.transfer != "undefined") 
				{
					console.log("]]] update.transfer = " + JSON.stringify(update.transfer) + "");
					if (manager.transferUpdateHandler)
					{
						manager.transferUpdateHandler(update.transfer);
					}
				}
				
				if (typeof update.deviceChanges != "undefined")
				{
					console.log("]]] update.deviceChanges = " + update.deviceChanges + "");
					manager.devicesChangedHandler();
				}
			};
				
			// Error calls failure callback (replace after open?)
			manager.websocket.onerror = function(evt) { 
				if (manager.isConnected)
				{
					manager.isConnected = false;
					if (manager.updatesLostHandler != null) { manager.updatesLostHandler(); }
				}
				manager.websocket = null;
				//if (callbackFailure) { callbackFailure(); }
				
				manager.reconnectInterval = 2 * manager.reconnectInterval;
				if (manager.reconnectInterval > 4) { manager.reconnectInterval = 4; }
				var reconnectTimer = manager.reconnectInterval * 1000;
				
console.log("Update connection error, retry in " + (reconnectTimer / 1000) + "...");

				setTimeout(function() { manager.reconnect(); }, reconnectTimer);
			};
		}
	}
	
	
	// Handlers
	manager.updatesLostHandler = null;
	manager.onUpdatesLost = function(handler) { manager.updatesLostHandler = handler; }
	manager.updatesResumedHandler = null;
	manager.onUpdatesResumed = function(handler) { manager.updatesResumedHandler = handler; }
	manager.devicesChangedHandler = null;
	manager.onDevicesChanged = function(handler) { manager.devicesChangedHandler = handler; }
	manager.receivedHandler = null;
	manager.onReceived = function(handler) { manager.receivedHandler = handler; }
	manager.transferUpdateHandler = null;
	manager.onTransferUpdate = function(handler) { manager.transferUpdateHandler = handler; }
	
	// Script version (see also manager.middlewareVersion - valid once connected)
	manager.version = 1;
	
	// OmmManager.start()
	manager.start = function (callbackSuccess, callbackFail, managerParameters) {
	    // Start status update connection
		if (managerParameters && managerParameters.domain)
		{ 
			manager.domain = managerParameters.domain;
		}
		manager.reconnect(function() {
			if (callbackSuccess) { callbackSuccess(); }
		});
	};

	return manager;
}());
